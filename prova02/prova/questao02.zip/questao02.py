# Sistema de chamados de TI
# Este programa é para uma prova inicial, então o código foi escrito de forma simples
# e fácil de entender.

# a. Estrutura de dados: chamados armazenados em uma lista de dicionários.
listaChamados = []
statusAberto = 'ABERTO'
statusConcluido = 'CONCLUÍDO'


def validarPrioridade(prioridade):
    prioridade = prioridade.upper()

    # b. Valida a prioridade e solicita uma nova entrada enquanto houver erro.
    while (prioridade != 'BAIXA'
           and prioridade != 'MEDIA'
           and prioridade != 'ALTA'):
        print('Prioridade inválida. Digite BAIXA, MEDIA ou ALTA.')
        prioridade = input('Digite a prioridade: ').upper()

    return prioridade

# Funções Obrigatórias: Implementar obrigatoriamente as seguintes funções estruturadas:
# i. adicionar_chamado(lista, id, usuario, descricao, prioridade): recebe os dados,
# monta o dicionário e insere na lista;
# ii. listar_chamados(lista, filtro_prioridade=None): percorre e imprime os chamados
# (com filtro opcional de prioridade ou todos caso None);
# iii. encerrar_chamado(lista, id): localiza pelo ID e altera status para 'CONCLUÍDO' (ou
# avisa caso não exista);
# iv. obter_total_abertos(lista): retorna a quantidade total de chamados ainda com
# status 'ABERTO'.

def adicionarChamado(lista, id, usuario, descricao, prioridade):
    chamado = {
        'id': id,
        'usuario': usuario,
        'descricao': descricao,
        'prioridade': prioridade,
        'status': statusAberto
    }

    lista.append(chamado)
    print(f'Chamado {id} cadastrado com sucesso!')


def listarChamados(lista, filtro_prioridade=None):
    print('\n--- CHAMADOS ---')

    encontrouChamado = False

    for chamado in lista:
        if (filtro_prioridade is None
                or chamado['prioridade'] == filtro_prioridade):
            print(f"ID: {chamado['id']} | Usuário: {chamado['usuario']} | "
                  f"Prioridade: {chamado['prioridade']} | Status: {chamado['status']} | "
                  f"Descrição: {chamado['descricao']}")
            encontrouChamado = True

    if not encontrouChamado:
        if filtro_prioridade is None:
            print('Nenhum chamado cadastrado.')
        else:
            print(f'Nenhum chamado encontrado com a prioridade {filtro_prioridade}.')


def encerrarChamado(lista, id):
    for chamado in lista:
        if chamado['id'] == id:
            chamado['status'] = statusConcluido
            print(f'Chamado {id} encerrado com sucesso!')
            return

    print(f'Chamado {id} não encontrado.')


def obterTotalAbertos(lista):
    totalAbertos = 0

    for chamado in lista:
        if chamado['status'] == statusAberto:
            totalAbertos += 1

    return totalAbertos


# d. Menu de console: permanece ativo até que a opção de saída seja escolhida.
def menu():
    proximoId = 1

    while True:
        print('\n===== SISTEMA DE CHAMADOS DE TI =====')
        print('1 - Novo Chamado')
        print('2 - Listar Todos')
        print('3 - Listar por Prioridade')
        print('4 - Encerrar Chamado')
        print('5 - Ver Quantidade de Abertos')
        print('0 - Sair')

        opcaoMenu = input('Escolha uma opção: ')

        if opcaoMenu == '1':
            usuarioChamado = input('Nome do usuário: ')
            descricaoChamado = input('Descrição do problema: ')
            prioridadeChamado = input('Prioridade (BAIXA, MEDIA, ALTA): ')
            prioridadeChamado = validar_prioridade(prioridadeChamado)
            adicionar_chamado(
                listaChamados,
                proximoId,
                usuarioChamado,
                descricaoChamado,
                prioridadeChamado
            )
            proximoId += 1

        elif opcaoMenu == '2':
            listar_chamados(listaChamados)

        elif opcaoMenu == '3':
            filtroPrioridade = input('Digite a prioridade para filtrar: ')
            filtroPrioridade = validar_prioridade(filtroPrioridade)
            listar_chamados(listaChamados, filtroPrioridade)

        elif opcaoMenu == '4':
            idChamado = int(input('Digite o ID do chamado para encerrar: '))
            encerrar_chamado(listaChamados, idChamado)

        elif opcaoMenu == '5':
            totalAbertos = obter_total_abertos(listaChamados)
            print(f'Total de chamados abertos: {totalAbertos}')

        elif opcaoMenu == '0':
            print('Sistema encerrado.')
            break

        else:
            print('Opção inválida.')


menu()
