# A divisão de vendas precisa automatizar
# a apuração de pedidos comerciais.
# Construa um programa em Python que realize a leitura
# do arquivo estruturado
# pedidos.csv (campos delimitados por ponto e vírgula';'),
#  aplique as regras de faturamento e
#   exiba um relatório no console.

# id_pedido;cliente;produto;quantidade;preco_unitario
# 101;Oficina Alfa;Teclado Mecanico;4;150.00
# 102;Metalurgica Beta;Monitor 27;12;85.50
# 103;AutoPecas Gama;Mouse Pad Gamer;8;210.00
# 104;Logistica Delta;Cabo HDMI;15;45.00
# 105;Mecanica Epsilon;Headset Sem Fio;3;320.00
import csv
# Regras de Negócio e Requisitos Técnicos:
# a) Abrir o arquivo utilizando tratamento de erros (try / except
# FileNotFoundError), exibindo mensagem amigável caso não seja localizado.
try: 
    with open("pedidos.csv", "r",encoding="utf-8") as arquivo:
        leitor = csv.DictReader(arquivo,delimiter=';')

# b) Valor Bruto: Para cada pedido,
# calcular Valor Bruto = quantidade * preco_unitario.
        for dado in leitor:
            quantidade = int(dado['quantidade'])
            preco_unitario = float(dado['preco_unitario'])
            valor_bruto = quantidade * preco_unitario
            #print(f"Id: {dado['id_pedido']}, Cliente: {dado['cliente']}, Bruto: {valor_bruto:.2f}")


# c) Desconto Progressivo: Se quantidade >= 10,
#  aplicar 10% de desconto sobre o bruto; se entre
# 6 e 9 (inclusive), aplicar 5% de desconto; se menos de 6, desconto de 0.00.
            if quantidade >= 10:
                desconto = valor_bruto * 0.10
            elif quantidade >= 6 and quantidade <= 9:
                desconto = valor_bruto * 0.05
            else:
                desconto = 0.00

 # d) Valor Líquido e Status: 
# Calcular Valor Líquido = Valor Bruto - Desconto. Se valor líquido >=
# 1000.00, classificar como 'PREMIUM', senão 'PADRÃO'.

            valorLiquido = valor_bruto - desconto
            if valorLiquido <= 1000.00:
                status = 'PADRÃO'
            else:
                status = 'PREMIUM'

 # e) Relatório Consolidado: 
# Exibir listagem tabular dos pedidos (ID, Cliente, Bruto, Desconto e
# Líquido em 2 casas decimais) e, ao final, Faturamento Bruto Total,
# Total de Descontos, Faturamento Líquido Total e dados do maior pedido líquido.
            print(f'Id: {dado["id_pedido"]}, Cliente: {dado["cliente"]}, Bruto: {valor_bruto:.2f}, Desconto: {desconto:.2f}, Líquido: {valorLiquido:.2f}, Status: {status}')

except FileNotFoundError:
    print('Arquivo não encontrado')