# Classe para gerenciamento de livros do acervo, sem utilizar heranca.
class Livros:
    def __init__(
        self,
        titulo: str,
        autor: str,
        ano_publicacao: int,
        disponivel: bool = True
    ):
        self.titulo = titulo
        self.autor = autor
        self.ano_publicacao = ano_publicacao
        self.disponivel = disponivel

    def emprestar(self):
        if self.disponivel:
            self.disponivel = False
            print(f'Livro "{self.titulo}" emprestado com sucesso.')
        else:
            print(f'O livro "{self.titulo}" ja esta emprestado.')

    def devolver(self):
        if not self.disponivel:
            self.disponivel = True
            print(f'Livro "{self.titulo}" devolvido com sucesso.')
        else:
            print(f'O livro "{self.titulo}" ja estava disponivel.')

    def situacao(self) -> str:
        return "Disponível" if self.disponivel else "Emprestado"

    def exibir_ficha_tecnica(self):
        print(
            f'Título: {self.titulo}\n'
            f'Autor: {self.autor}\n'
            f'Ano: {self.ano_publicacao}\n'
            f'Situação: {self.situacao()}'
        )


livro1 = Livros("Sex on the beat", "Valim", 2026)
livro2 = Livros("Sex on the ground", "Clara", 1999)

livro1.exibir_ficha_tecnica()
livro1.emprestar()
livro1.exibir_ficha_tecnica()
livro1.devolver()
livro2.exibir_ficha_tecnica()
